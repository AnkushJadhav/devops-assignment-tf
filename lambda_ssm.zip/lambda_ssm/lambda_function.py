import boto3
import time
import os



def lambda_handler(event, context):
    InstanceId=os.environ.get("instanceId")
    ssm_client = boto3.client('ssm')
    #runCMD = "echo 'Hello World'"
    response = ssm_client.send_command(
                InstanceIds=[InstanceId],
                DocumentName="AWS-RunShellScript",
                Parameters={'commands': ["echo 'Hello World'"]}, )

    commandId = response['Command']['CommandId']
    time.sleep(4)
    print(commandId)
    output = ssm_client.get_command_invocation(
        CommandId=commandId,
        InstanceId=InstanceId,
        )
    print(output.get('StandardOutputContent'))